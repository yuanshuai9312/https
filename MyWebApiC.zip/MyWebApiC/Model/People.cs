﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class People
    {
        public int Id { get; set; }
        public string Name  { get; set; }
        public string Age { get; set; }
        public string ClassId { get; set; }



    }
}
