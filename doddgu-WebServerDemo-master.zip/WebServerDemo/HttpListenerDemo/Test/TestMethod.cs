﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HttpListenerDemo.Test
{
    public class TestMethod
    {
        public string Test(string msg)
        {
            return "TestMethod：" + msg;
        }
    }
}
